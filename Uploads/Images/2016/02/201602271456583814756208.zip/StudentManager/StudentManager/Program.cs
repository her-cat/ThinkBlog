﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentManager
{
    class Student
    {
        private string[,] studentList = new string[10, 3];
        static void Main(string[] args)
        {
            Student stu = new Student();
            stu.Option();
        }

        //添加学生信息
        private void AddStudent()
        {
            char isStop = 'n';
            do
            {
                int i = 0;
                for (; i < 10; i++)
                {
                    if (this.studentList[i, 0] == null)
                    {
                        break;
                    }
                    else if (i == 9)
                    {
                        Console.WriteLine("学生信息已满！无法进行添加操作！");
                    }
                }
                if (i != 10)
                {
                    Console.WriteLine("请输入学生姓名：");
                    this.studentList[i, 0] = Console.ReadLine();
                    Console.WriteLine("请输入学生年龄：");
                    this.studentList[i, 1] = Console.ReadLine();
                    Console.WriteLine("请输入学生成绩：");
                    this.studentList[i, 2] = Console.ReadLine();
                    Console.WriteLine("学生\"{0}\"添加成功！", this.studentList[i, 0]);
                }
                Console.WriteLine("是否继续添加学生？ (y/n)");
                isStop = char.Parse(Console.ReadLine());
            } while (isStop == 'y');
        }

        //删除学生信息
        private void DeleteStudent()
        {
            char isStop = 'n';
            do
            {
                Console.WriteLine("请输入学生姓名：");
                string name = Console.ReadLine();
                for (int i = 0; i < 10; i++)
                {
                    if (this.studentList[i, 0] == name)
                    {
                        for (int j = 0; j < 3; j++)
                        {
                            this.studentList[i, j] = null;
                        }
                        Console.WriteLine("学生\"{0}\"删除成功！", name);
                        break;
                    }
                    else if (i == 9)
                    {
                        Console.WriteLine("学生\"{0}\"不存在！", name);
                    }
                }
                Console.WriteLine("是否继续删除？ (y/n)");
                isStop = char.Parse(Console.ReadLine());
            } while (isStop == 'y');
        }

        //修改学生信息
        private void ModifyStudent()
        {
            char isStop = 'n';
            do
            {
                Console.WriteLine("请输入学生姓名");
                string name = Console.ReadLine();
                for (int i = 0; i < 10; i++)
                {
                    if (this.studentList[i, 0] == name)
                    {
                        Console.WriteLine("请输入学生新年龄：");
                        this.studentList[i, 1] = Console.ReadLine();
                        Console.WriteLine("请输入学生新成绩：");
                        this.studentList[i, 2] = Console.ReadLine();
                        Console.WriteLine("学生\"{0}\"修改成功！", name);
                        break;
                    }
                    else if (i == 9)
                    {
                        Console.WriteLine("学生\"{0}\"不存在！", name);
                    }
                }
                Console.WriteLine("是否继续修改？ (y/n)");
                isStop = char.Parse(Console.ReadLine());
            } while (isStop == 'y');
        }

        //查询学生信息
        private void SearchStudent()
        {
            Console.WriteLine("请输入学生姓名：");
            string name = Console.ReadLine();
            for (int i = 0; i < 10; i++)
            {
                if (this.studentList[i, 0] == name)
                {
                    Console.WriteLine("姓名\t年龄\t成绩");
                    Console.WriteLine("{0}\t{1}\t{2}", this.studentList[i, 0], this.studentList[i, 1], this.studentList[i, 2]);
                }
            }

        }

        //显示学生列表
        private void ShowStudentList()
        {
            char isStop = 'n';
            do
            {
                Console.WriteLine("姓名\t年龄\t成绩");
                for (int i = 0; i < 10; i++)
                {
                    if (this.studentList[i, 0] != null)
                    {
                        Console.WriteLine("{0}\t{1}\t{2}", this.studentList[i, 0], this.studentList[i, 1], this.studentList[i, 2]);
                    }
                }
                Console.WriteLine("是否继续？ (y/n)");
                isStop = char.Parse(Console.ReadLine());
            } while (isStop == 'y');
        }

        //退出程序
        private void ExitProgram()
        {
            Console.WriteLine("欢迎下次使用！再见~");
            System.Environment.Exit(0);
        }

        //主菜单
        public void Option()
        {
            this.Init();    //初始化学生信息
            do
            {
                Console.WriteLine("----------------------\n-- 学生信息管理系统 --\n----------------------\n\n请选择：\n1.添加学生信息\n2.删除学生信息\n3.修改学生信息\n4.查询学生信息\n5.查看学生列表\n6.退出");
                int number = int.Parse(Console.ReadLine());
                if (number < 1 || number > 6)
                {
                    Console.WriteLine("输入的编号有误！请重新输入");
                }
                switch (number)
                {
                    case 1:
                        this.AddStudent();
                        break;
                    case 2:
                        this.DeleteStudent();
                        break;
                    case 3:
                        this.ModifyStudent();
                        break;
                    case 4:
                        this.SearchStudent();
                        break;
                    case 5:
                        this.ShowStudentList();
                        break;
                    case 6:
                        this.ExitProgram();
                        break;
                    default:
                        break;
                }
                Console.WriteLine("\n");
            } while (true);
        }

        //初始化学生信息
        private void Init(){
            string[,] info = new string[5, 3] { { "何湘辉", "18", "100" }, { "小明", "15", "86" }, { "小红", "17", "92" }, { "小白", "20", "67" }, { "小黄", "18", "95" } };
            for (int i = 0; i < 5; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    this.studentList[i, j] = info[i, j];
                }
            }
        }
    }
}
