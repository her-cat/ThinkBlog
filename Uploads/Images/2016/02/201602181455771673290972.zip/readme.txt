导入site.sql文件即可。
何湘辉博客
http://hexianghui.net