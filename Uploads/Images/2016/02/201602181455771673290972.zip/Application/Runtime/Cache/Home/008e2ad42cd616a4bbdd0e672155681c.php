<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>用户中心 - 何湘辉博客 hexianghui.net</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
</head>
<body>
<h2>>>>用户中心<<<</h2>
欢迎您～<?php echo ($name); ?>
<br/>
</body>
<footer>
<!--何湘辉博客_http://hexianghui.net-->
</footer>
</html>