<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>登录帐号 - 何湘辉博客 hexianghui.net</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<script>
function check_input(){
    if (login_form.name.value == ""){
        alert("用户名不能为空！");
        return false;
    }
    if (login_form.pwd.value == ""){
        alert("密码不能为空！");
        return false;
    }
}
</script>
</head>
<body>
<h2>>>>登录帐号<<<</h2>
<form name="login_form" action="<?php echo U('Index/login_do');?>" method="POST">
用户名：<input name="name" type="text"><br/>
密&nbsp;&nbsp;&nbsp;&nbsp;码：<input name="pwd" type="password"><br/>
<input name="submit" type="submit" value="登录" onclick="return check_input()">
</form>
<br/>
没有帐号？<a href="<?php echo U('Index/reg');?>">立即注册</a>
</body>
<footer>
<!--何湘辉博客_http://hexianghui.net-->
</footer>
</html>