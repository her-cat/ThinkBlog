<?php
/*
 * File: hxhFrame.php
 * Action: 登录/注册处理文件
 * Url: http://hexianghui.net
 * Author: 何湘辉
 * Date: 2016-2-18 12:50
 */
 
namespace Home\Controller;
use Think\Controller;
class IndexController extends Controller {
    public function index(){
        $this->display();
    }
    
    public function reg(){
        $this->display();
    }
    
    public function login_do(){
        $name = trim($_POST['name']);
        $pwd = md5(trim($_POST['pwd']));
        if($name == "" || $pwd== ""){
            $this->error('请输入帐号密码！', U('Index/index'));
        }
        $User = M('User');
        $userInfo = $User->where("name = '$name'")->find();
        if($userInfo){
            if($userInfo['pwd'] == $pwd){
                $_SESSION['name'] = $name;
                $this->success('登录成功！正在跳转个人中心~', U('Index/user'));
            }else{
                $this->error('登录失败！正在跳转登录页面~', U('Index/index'));
            }
        }else{
            $this->error('帐号不存在！正在跳转登录页面～', U('Index/index'));
        }
    }
    
    public function reg_do(){
        $name = trim($_POST['name']);
        $pwd = md5(trim($_POST['pwd']));
        if($name == "" || $pwd== ""){
            $this->error('请输入帐号密码！', U('Index/reg'));
        }
        $User = M('User');
        $userInfo = $User->where("name = '$name'")->find();
        if($userInfo){
            $this->error('用户名已存在！正在跳转注册页面～', U('Index/reg'));
        }else{
            $data['name'] = $name;
            $data['pwd'] = $pwd;
            $result = $User->add($data);
            if($result){
                $this->success('注册成功！正在跳转登录页面～', U('Index/index'));
            }else{
                $this->error('注册失败！正在跳转注册页面～', U('Index/reg'));
            }
        }
    }
    public function user(){
        $name = $_SESSION['name'];
        if(!isset($name)){
            $this->error('请先登录！正在跳转登录页面～', U('Index/index'));
        }
        $this->assign('name', $name);
        $this->display();
    }
}