<?php
/*
 * File: php_array.php
 * Url: hexianghui.net/article/
 * Author: 何湘辉
 * Description: 处理PHP数组常用的几个函数
 * Date: 2016-3-14 20:13
 */

//1.遍历数组
// $arr = array("one", "two", "three");
// echo '使用for()循环:<br/>';
// for($i = 0; $i < count($arr); $i++){
// 	echo 'key：' . $i . ' --- value：' . $arr[$i] . '<br/>';
// }
// echo '使用foreach()循环:<br/>';
// foreach($arr as $key => $value){
// 	echo 'key：' . $key . ' --- value：' . $value . '<br/>';
// }

//2.删除数组中重复元素
// $arr = array("one", "two", "three", "one", "four", "three");
// echo '使用array_unique()前：<br/>';
// print_r($arr);
// $result = array_unique($arr);
// echo '<br/>使用array_unique()后：<br/>';
// print_r($result);

//3.合并数组
// $arr = array("one", "two", "three");
// $arr2 = array("four", "five", "six");
// $result = array_merge($arr, $arr2);
// print_r($result);

//4.检测数组中是否存在某个值
// $arr = array("one", "two", "three");
// $value = "two";
// if (in_array($value, $arr)) {
// 	echo $value . '存在';
// }else{
// 	echo $value . '不存在';
// }

//5.搜索数值
// $arr = array("one", "two", "three");
// $value = "three";
// $result = array_search($value, $arr);
// if ($result === null) {
// 	echo $value . '不存在';
// }else{
// 	echo $result . '存在';
// }

//6.对数组进行排序
// $arr = array("b", "c", "a");
// echo '从低到高排序：<br/>';
// sort($arr);
// print_r($arr);
// echo '<br/>从高到低排序：<br/>';
// rsort($arr);
// print_r($arr);

//7.打乱数组顺序
// $arr = array("a", "b", "c");
// shuffle($arr);
// print_r($arr);